<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>


<div id="loginbox" width="400px">

<div id="title">INFO SIMBAKDA</div>
	<div id="isi" >
		<table bgcolor="">
		<tr>
            	<td rowspan="13" width="200px">
                	<img src="<?php echo base_url();?>public/images/icon_inprogress.gif" width="150px" height="150px" />
                </td>
		<td><FONT COLOR="RED"><B>Yth. UNTUK SEMUA PENGGUNA SIMBAKDA, DENGAN HORMAT KAMI MEMBERITAHUKAN BAHWA MULAI HARI INI 12/01/2016 </B></FONT></TD>
		</tr>
		<tr>		<td><FONT COLOR="RED"><B>ALAMAT SIMBAKDA DIALIHKAN KE http://192.168.17.2/simbakda_bantaeng u/ penginputan di Pojok ASI atau klik 
		<a href="http://192.168.17.2/simbakda_bantaeng">DISINI</a> </B></FONT></td>
		</tr>
		<tr>		<td><FONT COLOR="RED"><B>dan Akses ONLINE http://180.250.223.115/simbakda_bantaeng atau klik <a href="http://180.250.223.115/simbakda_bantaeng">DISINI</a></B></FONT></td>
		</tr>
		</table>

	</div>
</div>
