<div id="content">
    <div class="scroll">
    <?php
        echo $prev;
    ?>
    </div>
</div>